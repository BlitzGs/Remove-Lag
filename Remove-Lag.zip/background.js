chrome.runtime.onInstalled.addListener(() => {
  console.log("Deeeep.io Lag Reducer instalado!");
});

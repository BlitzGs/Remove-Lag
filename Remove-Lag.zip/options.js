document.getElementById("save").addEventListener("click", () => {
  const settings = {
    disableAnimations: document.getElementById("disableAnimations").checked,
    reduceGraphics: document.getElementById("reduceGraphics").checked,
    hideBackground: document.getElementById("hideBackground").checked
  };
  chrome.storage.sync.set(settings, () => {
    console.log("Configurações salvas");
  });
});

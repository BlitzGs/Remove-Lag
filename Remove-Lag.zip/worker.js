// worker.js
self.onmessage = function(e) {
  try {
    const result = performHeavyComputation(e.data); // Exemplo de função pesada
    self.postMessage(result); // Retorna o resultado para o thread principal
  } catch (error) {
    self.postMessage({ error: error.message }); // Envia erro ao thread principal
  }
};

function performHeavyComputation(data) {
  // Simulação de processamento intensivo
  let sum = 0;
  // Substitua o seguinte exemplo por seu processamento intensivo real
  for (let i = 0; i < data.length; i++) {
    sum += data[i];
  }
  return sum; // Retorna a soma como resultado
}

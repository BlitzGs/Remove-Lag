// worker.js
self.onmessage = function(e) {
  // Realize tarefas pesadas aqui
  const result = performHeavyComputation(e.data); // Exemplo de função pesada
  self.postMessage(result); // Retorna o resultado para o thread principal
};

function performHeavyComputation(data) {
  // Processamento intensivo
  return data; // Modifique conforme necessário
}

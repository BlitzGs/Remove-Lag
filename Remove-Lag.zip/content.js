// content.js

// Função 1: Desativar Animações Não Essenciais
function disableAnimations() {
  const style = document.createElement('style');
  style.innerHTML = '* { animation: none !important; transition: none !important; }';
  document.head.appendChild(style);
}

// Função 2: Remover Anúncios ou Conteúdo Indesejado
function removeAds() {
  // Seletor para identificar anúncios; ajuste conforme necessário
  const adSelectors = ['.ad', '.banner', 'iframe[src*="ads.com"]']; // Exemplo de seletores

  adSelectors.forEach(selector => {
    const ads = document.querySelectorAll(selector);
    ads.forEach(ad => ad.remove()); // Remove cada anúncio encontrado
  });
}

// Função 3: Otimizar Elementos Gráficos (Reduzir Qualidade das Imagens)
function reduceImageQuality() {
  document.querySelectorAll('img').forEach(img => {
    img.style.filter = 'blur(2px)'; // Aplica um leve desfoque nas imagens
  });
}

// Chama as funções de otimização
disableAnimations();
removeAds();
reduceImageQuality();
